document.getElementById('recreateView').addEventListener('click', () => {
    const viewName = document.getElementById('viewName').value;
    console.log(`View Name to recreate: ${viewName}`); // Debugging output

    fetch('http://localhost:3000/api/recreateView', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ viewName }) // Include the viewName in the request body
    })
    .then(response => response.text())
    .then(data => {
        console.log(`Server response: ${data}`); // Debugging output
        document.getElementById('message').innerText = data;
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('message').innerText = 'An error occurred while recreating the view.';
    });
});
