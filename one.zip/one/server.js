const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const fs = require('fs');
const https = require('https');
const readXlsxFile = require('read-excel-file/node');
const csvParser = require('csv-parser');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });

const app = express();
const port = 3000;

const db = new sqlite3.Database('./data/mydatabase.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
    if (err) console.error('Error connecting to the SQLite database:', err.message);
    else console.log('Connected to the SQLite database.');
});

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(express.json());


const sfODataUrl = 'https://api12preview.sapsf.eu/odata/v2';
const username = 'user@companyid';
const password = 'password';


const base64Credentials = Buffer.from(`${username}:${password}`).toString('base64');

function isDateString(value) {
    // This regex matches strings in the format /Date(1591017600000)/
    return typeof value === 'string' && /\/Date\((\d+)(?:[+-]\d+)?\)\//.test(value);
}

function convertDateString(dateString) {
    // Extract milliseconds from the date string /Date(1591017600000)/
    const match = dateString.match(/\/Date\((\d+)(?:[+-]\d+)?\)\//);
    if (match) {
        // Convert milliseconds to a Date object and then to ISO string
        const date = new Date(parseInt(match[1], 10));
        return date.toISOString();
    } else {
        // Return the original string if it doesn't match the expected format
        return dateString;
    }
}

function flattenObject(obj, parentPrefix = '', separator = '.') {
    let flatObject = {};
    Object.keys(obj).forEach(key => {
        let newKey = parentPrefix ? `${parentPrefix}${separator}${key}` : key;
        if (typeof obj[key] === 'object' && !Array.isArray(obj[key]) && obj[key] !== null && !isDateString(obj[key])) {
            Object.assign(flatObject, flattenObject(obj[key], newKey, separator));
        } else {
            flatObject[newKey] = isDateString(obj[key]) ? convertDateString(obj[key]) : obj[key];
        }
    });
    return flatObject;
}

// Endpoint to fetch fields for a given table name
app.get('/api/fields/:tableName', (req, res) => {
    const { tableName } = req.params;

    // SQLite query to get column names for a table
    const query = `PRAGMA table_info(${tableName})`;

    db.all(query, [], (err, rows) => {
        if (err) {
            console.error(err.message);
            res.status(500).send('Error fetching table fields');
            return;
        }
        const fields = rows.map(row => row.name);
        res.json(fields);
    });
});

// Endpoint to create view
// Parse JSON bodies
app.use(bodyParser.json());

// Your routes and other middleware setup...

app.post('/api/create-view', (req, res) => {
    const { tables } = req.body;
    console.log('tables:', req, tables);
    // Check if `tables` is defined
    if (!tables) {
        return res.status(400).send({ error: 'Tables data is missing' });
    }

    // Rest of your route handling logic...

    console.log("Received tables data:", tables);

    // Construct the SQL statement based on `tables`
    // This part depends on the structure of `tables` and how you want to create the view
    let selectColumns = [];
    let fromTables = [];

    tables.forEach(table => {
        const { name, viewColumns, baseTable, relation } = table;
        if (baseTable || relation) {
            selectColumns.push(`${name}.*`);
            fromTables.push(name);
        }
        if (viewColumns && viewColumns.length > 0) {
            viewColumns.forEach(column => {
                selectColumns.push(`${name}.${column}`);
            });
        }
    });

    // Rest of your code...

    res.send({ message: 'View created successfully' });
});




// Endpoint to get a list of all tables
app.get('/api/tables', (req, res) => {
    const sql = `SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;`;

    db.all(sql, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        // Assuming you want to send back just the names of the tables
        const tableNames = rows.map(row => row.name);
        res.json(tableNames);
    });
});

// Make sure to close the database connection when your app stops
process.on('SIGINT', () => {
    db.close(() => {
        console.log('Database connection closed.');
        process.exit(0);
    });
});


app.post('/:action(populate|delete)', async (req, res) => {
    const { action } = req.params;
    let { sets } = req.body;

    console.log(`Received action: ${action}`, sets);

    if (!Array.isArray(sets)) {
        console.error('Error: "sets" is not an array');
        return res.status(400).send('Expected "sets" to be an array.');
    } else {

        // Remove null values from the sets array
        sets = sets.filter(item => item !== null);
    }

    console.log('sets:', sets);
    try {
        for (const set of sets) {
            console.log(`Processing set:`, set);

            const { tableName, entitySet, action: setAction, addTimestamp, fullExtract } = set;
            let modifiedTableName = tableName;

            if (addTimestamp) modifiedTableName += `_${Date.now()}`;
            console.log(`Modified table name: ${modifiedTableName}`);

            const fetchedData = await fetchODataAndPopulate(entitySet, fullExtract);
            if (!fetchedData || fetchedData.length === 0) {
                console.log(`No data available for entitySet: ${entitySet}`);
                continue;
            }

            const cleanedData = fetchedData.map(entry => {
                const { __metadata, ...cleanEntry } = entry;
                return cleanEntry;
            });

            if (action === 'populate') {
                if (setAction === 'deleteAndRecreate') {
                    console.log(`Deleting and recreating table: ${modifiedTableName}`);
                    await deleteTable(modifiedTableName);
                    await createTable(modifiedTableName, cleanedData[0]);
                } else if (setAction === 'appendToExisting') {
                    const tableExists = await checkTableExists(modifiedTableName);
                    if (!tableExists) {
                        console.log(`Creating table: ${modifiedTableName}`);
                        await createTable(modifiedTableName, cleanedData[0]);
                    }
                } else if (setAction === 'deleteExistingRecords') {
                    console.log(`Deleting existing records from table: ${modifiedTableName}`);
                    await deleteExistingRecords(modifiedTableName);
                }

                console.log(`Inserting data into table: ${modifiedTableName}`);
                await insertData(modifiedTableName, cleanedData);
            }
        }
        res.json({ message: 'Action populate completed successfully.' });

        // res.status(200).send(`Action ${action} completed successfully for all sets.`);
    } catch (error) {
        console.error(`Error during ${action}:`, error);
        res.status(500).send(`Error during ${action}: ${error.message}`);
    }
});

async function createTable(tableName, sampleData) {
    const columns = Object.keys(sampleData).map(column => `[${column}] TEXT`).join(', ');
    const sql = `CREATE TABLE IF NOT EXISTS ${tableName} (id INTEGER PRIMARY KEY AUTOINCREMENT, ${columns})`;
    return new Promise((resolve, reject) => {
        db.run(sql, (err) => {
            if (err) {
                console.error(`Error creating table ${tableName}:`, err);
                reject(err);
            } else {
                console.log(`Table ${tableName} created or already exists.`);
                resolve();
            }
        });
    });
}

async function insertData(tableName, data) {
    console.log(`Starting data insertion for table: ${tableName}`);
    if (!Array.isArray(data) || data.length === 0) {
        console.error("Error: No data provided for insertion");
        throw new Error("No data provided for insertion");
    }
    console.log(`Data received for insertion:`, data);
    const processedData = data.map(row => flattenObject(row));
    const columns = Object.keys(processedData[0]).map(column => `"${column}"`).join(', ');
    const placeholders = Object.keys(processedData[0]).map(() => '?').join(', ');
    const sql = `INSERT INTO "${tableName}" (${columns}) VALUES (${placeholders})`;
    console.log(`Prepared SQL: ${sql}`);
    const insertStmt = db.prepare(sql, function (err) {
        if (err) {
            console.error(`Error preparing insert statement for ${tableName}:`, err);
            throw err;
        }
    });

    return new Promise((resolve, reject) => {
        db.serialize(() => {
            processedData.forEach((row, index) => {
                const values = Object.values(row);
                console.log(`Inserting row ${index + 1}:`, values);
                insertStmt.run(values, function (err) {
                    if (err) {
                        console.error(`Error inserting row into ${tableName}:`, err);
                        reject(err);
                    } else {
                        console.log(`Row ${index + 1} inserted successfully.`);
                    }
                });
            });
            insertStmt.finalize((err) => {
                if (err) {
                    console.error(`Error finalizing insert statement for ${tableName}:`, err);
                    reject(err);
                } else {
                    console.log(`Data insertion completed successfully for table: ${tableName}`);
                    resolve();
                }
            });
        });
    });
}

async function fetchODataAndPopulate(entitySet, fullExtract) {
    if (!entitySet) {
        console.error("EntitySet is undefined");
        return [];
    }
    const apiUrl = `${sfODataUrl}/${entitySet}`;
    console.log(`Fetching data from: ${apiUrl}`);
    let allData = [];
    try {
        const agent = new https.Agent({ rejectUnauthorized: false });
        let nextUrl = apiUrl;
        if (fullExtract) {
            do {
                const response = await axios.get(nextUrl, {
                    headers: { Authorization: `Basic ${base64Credentials}` },
                    httpsAgent: agent
                });
                allData = allData.concat(response.data.d.results);
                nextUrl = response.data.d.__next || null;
            } while (nextUrl);
        } else {
            const response = await axios.get(nextUrl, {
                headers: { Authorization: `Basic ${base64Credentials}` },
                httpsAgent: agent
            });
            allData = response.data.d.results;
        }
        console.log(`Fetched data for ${entitySet}:`, allData);
    } catch (error) {
        console.error(`Error fetching data for ${entitySet}:`, error);
        return [];
    }
    if (Array.isArray(allData)) {
        return allData.map(item => flattenObject(item));
    } else if (typeof allData === 'object') {
        return [flattenObject(allData)];
    } else {
        return [];
    }
}

async function deleteTable(tableName) {
    return new Promise((resolve, reject) => {
        db.run(`DROP TABLE IF EXISTS "${tableName}"`, (err) => {
            if (err) {
                console.error(`Error deleting table ${tableName}:`, err);
                reject(err);
            } else {
                console.log(`Table ${tableName} deleted.`);
                resolve();
            }
        });
    });
}

async function deleteExistingRecords(tableName) {
    return new Promise((resolve, reject) => {
        db.run(`DELETE FROM ${tableName}`, (err) => {
            if (err) {
                console.error(`Error deleting records from ${tableName}:`, err);
                reject(err);
            } else {
                console.log(`Existing records deleted from table: ${tableName}`);
                resolve();
            }
        });
    });
}

app.post('/upload', upload.single('file'), async (req, res) => {
    const tableName = req.body.tableName;
    const action = req.body.actionOnExistingTable;
    const file = req.file;
    if (!file) {
        return res.status(400).send({ message: 'No file uploaded.' });
    }
    try {
        const data = await parseFile(file.path, file.mimetype);
        switch (action) {
            case 'deleteAndRecreate':
                await deleteTable(tableName);
                await createTable(tableName, data[0]);
                break;
            case 'appendToExisting':
                const tableExists = await checkTableExists(tableName);
                if (!tableExists) await createTable(tableName, data[0]);
                break;
            case 'deleteExistingRecords':
                await deleteExistingRecords(tableName);
                break;
            default:
                return res.status(400).send({ message: 'Invalid action.' });
        }
        await insertData(tableName, data);
        console.log(`Data from file uploaded successfully to table: ${tableName}`);
        res.send({ message: 'Data uploaded successfully.' });
    } catch (error) {
        console.error(`Error processing file upload for ${tableName}:`, error);
        res.status(500).send({ message: 'Error processing file.' });
    } finally {
        fs.unlinkSync(file.path);
    }
});

async function parseFile(filePath, mimeType) {
    if (mimeType === 'text/csv') {
        return parseCSV(filePath);
    } else if (mimeType.includes('excel') || mimeType.includes('spreadsheetml')) {
        return parseExcel(filePath);
    } else {
        console.error(`Unsupported file type for parsing: ${mimeType}`);
        throw new Error('Unsupported file type');
    }
}

function parseCSV(filePath) {
    return new Promise((resolve, reject) => {
        const results = [];
        fs.createReadStream(filePath)
            .pipe(csvParser())
            .on('data', (data) => {
                console.log(`CSV Row:`, data);
                results.push(data);
            })
            .on('end', () => {
                console.log(`CSV file ${filePath} parsed successfully.`);
                resolve(results);
            })
            .on('error', (err) => {
                console.error(`Error parsing CSV file ${filePath}:`, err);
                reject(err);
            });
    });
}

function parseExcel(filePath) {
    return readXlsxFile(filePath).then((rows) => {
        const headers = rows[0];
        const data = rows.slice(1).map((row) => {
            const rowData = {};
            row.forEach((value, index) => {
                rowData[headers[index]] = value;
            });
            return rowData;
        });
        console.log(`Excel file ${filePath} parsed successfully.`);
        return data;
    });
}

async function checkTableExists(tableName) {
    return new Promise((resolve, reject) => {
        db.get(`SELECT name FROM sqlite_master WHERE type='table' AND name=?`, [tableName], (err, row) => {
            if (err) {
                console.error(`Error checking if table ${tableName} exists:`, err);
                reject(err);
            } else {
                resolve(!!row);
            }
        });
    });
}



// Open the database
// let db = new sqlite3.Database('./path_to_your_sqlite_db.db', sqlite3.OPEN_READWRITE, (err) => {
//     if (err) {
//       console.error(err.message);
//       return;
//     }
//     console.log('Connected to the SQLite database.');
//   });
// API endpoint to recreate a view
app.post('/api/recreateView', (req, res) => {
    const viewName = req.body.viewName;
    console.log(`API Request: Recreate View - View Name: ${viewName}`);

    if (!viewName) {
        console.log("View name is required but not provided.");
        return res.status(400).send('View name is required.');
    }

    recreateView(viewName, res);
});

function recreateView(viewName, res) {
    console.log(`Checking if view exists: ${viewName}`);

    db.get(`SELECT name FROM sqlite_master WHERE type='view' AND name=?`, [viewName], (err, row) => {
        if (err) {
            console.error("Error checking for existing view:", err.message);
            return res.status(500).send('Error checking for existing view.');
        }

        if (row) {
            console.log(`View exists, dropping view: ${viewName}`);
            db.run(`DROP VIEW ${viewName}`, [], (dropErr) => {
                if (dropErr) {
                    console.error("Error dropping existing view:", dropErr.message);
                    return res.status(500).send('Error dropping existing view.');
                }
                console.log(`View dropped successfully: ${viewName}`);
                createView(viewName, res);
            });
        } else {
            console.log(`View does not exist, creating view: ${viewName}`);
            createView(viewName, res);
        }
    });
}
function createView(viewName, res) {
    console.log(`Fetching view details for view creation: ${viewName}`);

    db.all(`SELECT * FROM viewtable WHERE ViewNameCorrected = ?`, [viewName], (err, rows) => {
        if (err) {
            console.error("Error fetching view details:", err.message);
            return res.status(500).send('Error fetching view details.');
        }

        if (rows.length === 0) {
            console.log(`No details found for the view name: ${viewName}`);
            return res.status(404).send(`No details found for the view name: ${viewName}`);
        }

        let selectClauses = [];
        let joinClauses = []; // Use an array to store all join clauses

        // Determine the base table, typically the one without a RelationTable value or marked with 'X'
        let baseTableRow = rows.find(row => row.baseTable === 'X');
        let fromTable = baseTableRow ? baseTableRow.TableName : rows[0].TableName;

        rows.forEach(row => {
            // Add the field to the SELECT clause with alias
            selectClauses.push(`${row.TableName}.${row.field} AS '${row.TableName}_${row.field}'`);

            // Build the JOIN clause if RelationTable and RelationField have values
            if (row.RelationTable && row.RelationField) {
                // Ensure that the JOIN is between different tables and that it's not already included
                if (row.TableName !== row.RelationTable) {
                    const joinCondition = `LEFT JOIN ${row.TableName} ON ${row.TableName}.${row.RelationField} = ${row.RelationTable}.${row.RelationField}`;
                    if (!joinClauses.includes(joinCondition)) {
                        joinClauses.push(joinCondition);
                    }
                }
            }
        });

        // Construct the SQL statement for creating the view
        const sqlSelect = selectClauses.join(', ');
        const sqlJoins = joinClauses.join(' ');
        let sql = `CREATE VIEW IF NOT EXISTS ${viewName} AS SELECT ${sqlSelect} FROM ${fromTable} ${sqlJoins}`;
        console.log(`Executing SQL to create view: ${sql}`);

        // Execute the SQL command to create the view
        db.run(sql, [], (error) => {
            if (error) {
                console.error("Error creating view:", error.message);
                return res.status(500).send(`Error creating view: ${viewName}.`);
            }
            console.log(`View '${viewName}' created successfully.`);
            res.send(`View '${viewName}' created successfully.`);
        });
    });
}





















app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
